<?php 

namespace Drupal\customdb\Form; 

use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

class CustomdbForm extends FormBase {
  public function getFormId(){
      return 'custom_form_id';
  }

  public function buildForm(array $form, FormStateInterface $form_state){
    $form['email'] = array(
        '#title' => t('Email Address'),
        '#type' => 'textfield',
        '#size' => 25,
        '#required' => TRUE,
        '#description' => t('User Email'),
    );

    $form['name'] = array(
      '#title' => t('Name'),
      '#type' => 'textfield',
      '#size' => 25,
      '#required' => TRUE,
      '#description' => t('User Name'),
  );


   

    $form['submit'] = array(
        '#type' => 'submit',
        '#value' => t('submit'),
    );

    return $form;

  }


public function validateForm(array &$form, FormStateInterface $form_state) {
 
}

  public function submitForm(array &$form, FormStateInterface $form_state)
  {
    db_insert('customdb')
      ->fields(array(
        'mail' => $form_state->getValue('email'),
        'name' => $form_state->getValue('name'),
        'created' => time(),
       ))
      ->execute();
      drupal_set_message(t('Your form has been submitted'));
  }
    
}
